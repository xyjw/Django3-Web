from django.apps import AppConfig


class ShopperConfig(AppConfig):
    name = 'shopper'
