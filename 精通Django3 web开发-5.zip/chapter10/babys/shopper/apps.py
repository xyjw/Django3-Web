from django.apps import AppConfig


class ShopperConfig(AppConfig):
    name = 'shopper'
    verbose_name = '订单管理'
